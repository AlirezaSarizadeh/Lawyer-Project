


function initCategoryBar() {
  var $overlay = $(".js-menu-overlay"),
    $naviOverlay = $(".js-navi-overlay"),
    $megaMenuMain = $('.js-mega-menu-main-item'),
    $megaMenuOptionsContainer = $(".js-mega-menu-categories-options"),
    $hoverEffect = $(".js-navi-new-list-category-hover"),
    $headerLinks = $('.js-categories-bar-item'),
    $megaMenuCategory = $('.js-mega-menu-category'),
    $searchBar = $('.js-search'),
    $searchResults = $('.js-search-results');

  var moveHover = function (self) {
    var parent = self
      .parent()
      .parent()
      .parent();

    $hoverEffect
      .css("width", self.width())
      .css(
        "right",
        parent.width() -
        (self.offset().left + self.width()) +
        parent.offset().left
      );
    $hoverEffect.css("transform", "scaleX(1)");
  };

  var removeHover = function () {
    $hoverEffect.css("transform", "scaleX(0)");
  };

  $headerLinks.hover(function () {
      moveHover.call(this, $(this));
    },
    function () {
      removeHover.call(this, $(this));
    });

  $megaMenuMain.on('click', function (e) {
    e.stopPropagation();
  });

  var hoverAction;
  $megaMenuMain.hover(
    function () {
      var $this = $(this);
      hoverAction = setTimeout(function () {
        $this.children(".js-mega-menu-categories-options").css('display', 'flex');
        $naviOverlay.addClass("is-active");
        $searchResults.removeClass("is-active");
        $searchBar.removeClass("is-active");
      }, 200);
    },
    function () {
      hoverAction && clearTimeout(hoverAction);
      $naviOverlay.removeClass("is-active");
      $megaMenuOptionsContainer.hide()
    });

  $megaMenuCategory.hover(
    function () {


      $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
      $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


      $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
      $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
      $(this).addClass('c-navi-new-list__inner-category--hovered');
      $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
    },

    function () {}
  );

  $overlay.hover(function () {
    if (!$(this).is(".is-active")) return true;
  });

  $megaMenuCategory.hover(
    function () {


      $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
      $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


      $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
      $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
      $(this).addClass('c-navi-new-list__inner-category--hovered');
      $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
    },

    function () {}
  );

};

function initStatic() {
  var $overlay = $(".js-menu-overlay"),
    $naviOverlay = $(".js-navi-overlay"),
    $newCategories = $(".js-navi-new-list-categories"),
    $newCategoryItem = $(".js-navi-new-list-category"),
    $hoverEffect = $(".js-navi-new-list-category-hover"),
    allCategoriesButton = $(".js-navi-new-list__all-links"),
    sentBanners = [];

  this.openCategories = false;
  var mainJs = this;

  $(".js-navi").hover(function () {
    $(this)
      .find("img[data-src]")
      .each(function () {
        $(this)
          .attr("src", $(this).attr("data-src"))
          .removeAttr("data-src");
      });
  });

  var moveHover = function (self) {
    var parent = self
      .parent()
      .parent()
      .parent();

    $hoverEffect
      .css("width", self.width())
      .css(
        "right",
        parent.width() -
        (self.offset().left + self.width()) +
        parent.offset().left
      );
    if ($(this).hasClass("is-fmcg")) {
      $hoverEffect.addClass("is-fmcg");
    } else {
      $hoverEffect.removeClass("is-fmcg");
    }
    $hoverEffect.css("transform", "scaleX(1)");
  };

  var removeHover = function () {
    $hoverEffect.css("transform", "scaleX(0)");
  };

  var handlerHover = function () {
    clearTimeout(this.closeTimer);
    var self = $(this);

    this.timer = setTimeout(function () {
      $("body").click();
      $naviOverlay.addClass("is-active");
      self.addClass("can-show-menu");
      self.siblings(".js-navi-new-list-category").addClass("can-show-menu");
      self.find(".js-navi-new-list-category").addClass("can-show-menu");
      mainJs.openCategories = true;
      var id = self.find(".c-adplacement__item").data("id");

      if (id && sentBanners.indexOf(id) < 0) {
        snt("dkBannerViewed", {
          bannerId: id,
          created_at: Date.now()
        });
        sentBanners.push(id);
      }
      $(".js-search-results").removeClass("is-active");
    }, 200);
    if (self.hasClass("js-navi-new-list-category")) {
      moveHover.call(this, self);
    }
  };
  var handlerOut = function () {
    clearTimeout(this.timer);
    var self = this;

    this.closeTimer = setTimeout(function () {
      if ($(".js-search-results").hasClass("is-active")) return;
      $(self).hasClass("js-navi-new-list-categories") ?
        $naviOverlay.removeClass("is-active") :
        "";
      $(self)
        .find(".js-navi-new-list-category")
        .removeClass("can-show-menu");
      $(self).hasClass("can-show-menu") ?
        $(self).removeClass("can-show-menu") :
        "";
      mainJs.openCategories = false;
    }, 200);
    removeHover();
  };

  // $('.js-navi-list-promotion-item').hover(function () {
  //     moveHover.call(this, $(this));
  // }, removeHover);

  var $w = $(window),
    lastY = $w.scrollTop();

  $(window).scroll(function () {
    var currentPosition = $w.scrollTop();

    if (!mainJs.openCategories) {
      return (lastY = currentPosition);
    }
    if (currentPosition - lastY < -5) {
      var e = jQuery.Event("mouseout");

      $newCategories.trigger(e);

      $newCategoryItem.trigger(e);
    }
    lastY = currentPosition;
  });

  $newCategories.hover(handlerHover, handlerOut);
  $newCategoryItem.hover(handlerHover, handlerOut);
  allCategoriesButton.hover(function (e) {
    e.stopPropagation();
    e.preventDefault();
    $naviOverlay.removeClass("is-active");
  });
  $overlay.hover(function () {
    if (!$(this).is(".is-active")) return true;
  });

  $(".js-expert-article-button").on("click", function (e) {
    var $this = $(this),
      $article = $this.closest(".js-expert-article");

    if ($article.hasClass("is-active")) {
      $article.removeClass("is-active");
    } else {
      $article.addClass("is-active");
    }

    e.preventDefault();

    window.dispatchEvent(new Event("scroll"));
  });

  var $deliveryLabels = $(".js-delivery-label");

  $deliveryLabels.click(function () {
    var $this = $(this);

    if ($this.hasClass("is-read-only")) {
      return;
    }

    $deliveryLabels.removeClass("is-selected");
    $this.addClass("is-selected");
  });

  $deliveryLabels.each(function () {
    var $this = $(this);
    var $radio = $this.find('input[type="radio"]');

    if ($radio.is(":checked")) {
      $this.addClass("is-selected");
    }
  });
};
$(document).ready(function () {
  initCategoryBar();
  initStatic();

});

if ($('.owl-slider').length) {
  $(document).ready(function () {
    var owl = $('.owl-slider');
    $('.owl-slider').owlCarousel({
      loop: true,
      margin: 0,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
      autoplay: true,
      navSpeed: 500,
      items: 1,
      rtl: true,
      dots: true,
      autoplay: true,
      responsive: {
        0: {
          nav: false
        },
        768: {
          nav: false
        }


      }
    });

 
   
  });
}
//   if (matchMedia('only screen and (min-width: 992px)').matches) {
// var heroSlider = $('.owl-newest');
// var owlCarouselTimeout = 3500;
$('.owl-logo').owlCarousel({
  autoplay: false,
  //loop: true,
  //autoplayHoverPause: true,
  smartSpeed: 450,
  rtl: true,
  margin: 0,
  loop:true,
  dots: true,
  margin: 13,
  lazyLoad: true,
  responsive: {
    0: {
      items: 2,
      nav: false,
      stagePadding: 30

    },

    400: {
      items: 2,
      nav: false,
      stagePadding: 30
    },
    768: {
      items: 3,
      nav: false,

    },
    1200: {
      items: 6,
      nav: true,
      dots:true

    }

  }
});
//   }

//   if (matchMedia('only screen and (min-width: 768px)').matches) {
$('.owl-send').owlCarousel({
  // autoplay: true,
  loop: false,
  rtl: true,
  nav: false,
  margin: 10,
  navText: ["<i class='fas fa-angle-left'></i>", "<i class='fas fa-angle-right'></i>"],
  lazyLoad: true,
  responsive: {
    0: {
      items: 3,
      dots: true
    },
    500: {
      items: 3,
      dots: true
    },
    768: {
      items: 4,
      dots: true
    },
    1200: {
      items: 4,
      touchDrag: false,
      mouseDrag: false
    }

  }
});

//   }

$('.scrollup').click(function () {
  $("html,body").animate({
    scrollTop: 0
  }, 1000);
  return false;
});


if (matchMedia('only screen and (max-width: 767.99px)').matches) {
  $(".set > span").on("click", function () {
    if ($(this).hasClass('active')) {
      $(this).removeClass("active");
      $(this).siblings('.content').slideUp(200);
      $(".set > span i").removeClass("fal fa-chevron-up").addClass("fal fa-chevron-down");
    } else {
      $(".set > span i").removeClass("fal fa-chevron-up").addClass("fal fa-chevron-down");
      $(this).find("i").removeClass("fal fa-chevron-down").addClass("fal fa-chevron-up");
      $(".set > span").removeClass("active");
      $(this).addClass("active");
      $('.content').slideUp(200);
      $(this).siblings('.content').slideDown(200);
    }

  });
}
$('.menuTrigger').click(function () {
  $('.panel-menu').toggleClass('isOpen');

});

$('.openSubPanel').click(function () {
  $(this).next('.subPanel').addClass('isOpen');
});

$('.closeSubPanel').click(function () {
  $(this).closest(".subPanel").removeClass("isOpen");
});

$("#panel-menu").on("click", function (e) {
  var target = $(e.target);
  if (target.attr('id') == 'menu-toggle' || target.parents('#panel-menu').length > 0 || target.parents('.panel-menu').length > 0) {
    console.log('id: ' + target.attr('id') + 'contains: ' + $.contains(target, $('.panel-menu')));
  } else {
    if ($(".panel-menu").hasClass('isOpen'))
      $(".panel-menu").removeClass("isOpen");
    $('.subPanel').removeClass('isOpen');
  }

});

$('.closePanel').click(function () {
  $('.panel-menu').removeClass('isOpen');
  $('.subPanel').removeClass('isOpen');

});


//if (matchMedia('only screen and (min-width: 768px)').matches) {
//    $(document).ready(function () {
//      $(window).scroll(function () {
//        if ($(window).scrollTop() > 50) {
//          $(".c-header.js-header").addClass("fixed");
//        } else {
//          $(".c-header.js-header").removeClass("fixed");
//        }
//      });
//    });
//  }

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
jQuery(document).ready(function () {
  var sync1 = jQuery("#sync1");
  var sync2 = jQuery("#sync2");
  var slidesPerPage = 3; //globaly define number of elements per page
  var syncedSecondary = true;

  sync1
    .owlCarousel({
      rtl: true,
      slideSpeed: 3000,
      nav: true,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
      loop: true,
      autoplayHoverPause: true,
      autoplaySpeed: 1400,


      responsiveClass: true,
      responsive: {
        0: {
          loop: true,
          items: 1,
          margin: 15,
          dots: true,
          autoplay: true
        },

        600: {
          loop: true,
          items: 2,
          margin: 15,
          dots: true,
          autoplay: true
        },
        768: {
          loop: true,
          items: 1,
          dots: false,
          margin: 15,
          animateIn: "fadeIn",
          autoplay: true
        }
      },
      responsiveRefreshRate: 200,

    })
    .on("changed.owl.carousel", syncPosition);

  sync2
    .on("initialized.owl.carousel", function () {
      sync2
        .find(".owl-item")
        .eq(0)
        .addClass("current");
    })
    .owlCarousel({
      rtl: true,
      margin: 10,
      loop: true,
      dots: false,
      nav: false,
      smartSpeed: 1000,
      slideSpeed: 1000,
      slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
      responsiveRefreshRate: 100,
      responsive: {
        0: {
          items: 1,
          margin: 10,
          autoplay: false
        },
        768: {
          items: slidesPerPage,
          autoplay: true
        }
      },
    })
    .on("changed.owl.carousel", syncPosition2);

  function syncPosition(el) {
    //if you set loop to false, you have to restore this next line
    //var current = el.item.index;

    //if you disable loop you have to comment this block
    var count = el.item.count - 1;
    var current = Math.round(el.item.index - el.item.count / 2 - 0.5);

    if (current < 0) {
      current = count;
    }
    if (current > count) {
      current = 0;
    }

    //end block

    sync2
      .find(".owl-item")
      .removeClass("current")
      .eq(current)
      .addClass("current");
    var onscreen = sync2.find(".owl-item.active").length - 1;
    var start = sync2
      .find(".owl-item.active")
      .first()
      .index();
    var end = sync2
      .find(".owl-item.active")
      .last()
      .index();

    if (current > end) {
      sync2.data("owl.carousel").to(current, 100, true);
    }
    if (current < start) {
      sync2.data("owl.carousel").to(current - onscreen, 100, true);
    }
  }

  function syncPosition2(el) {
    if (syncedSecondary) {
      var number = el.item.index;
      sync1.data("owl.carousel").to(number, 100, true);
    }
  }

  sync2.on("click", ".owl-item", function (e) {
    e.preventDefault();
    var number = jQuery(this).index();
    sync1.data("owl.carousel").to(number, 300, true);
  });
});

if ($('.owl-blog').length) {
  var heroSlider = $('.owl-blog');
  var owlCarouselTimeout = 3500;
  $('.owl-blog').owlCarousel({
    //autoplay: true,
    //loop: true,
    smartSpeed: 1000,
    rtl: true,
    margin: 20,

    lazyLoad: true,
    responsive: {
      0: {
        dots: true,
        nav: false,
        stagePadding: 40,
        items: 1
      },
      500: {
        dots: true,
        nav: false,
        items: 2
      },
      768: {
        dots: false,
        nav: true,
        items: 3

      },
      1200: {
        dots: false,
        nav: true,
        items: 4

      }

    }
  });
}
new WOW().init();
$(document).ready(function() {
  if ($('.select').length) {
    $('.select').select2({

        });
    }

  });
  
$(function(){
  var rwdMenu = $('.rwd-menu'),
      topMenu = $('.rwd-menu > li > a'),
      parentLi = $('.rwd-menu > li'),
      backBtn = $('.back-btn');
  
  topMenu.on('click',function(e){
    
    var thisTopMenu = $(this).parent(); // current $this
      rwdMenu.addClass('rwd-menu-view');
      parentLi.removeClass('open-submenu');
      thisTopMenu.addClass('open-submenu'); 
  });
  
  backBtn.click(function(){
    var thisBackBtn = $(this);
    parentLi.removeClass();
    rwdMenu.removeClass('rwd-menu-view');
  });
  
  
});